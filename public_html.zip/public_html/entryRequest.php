<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'DB_Functions.php';
$db = new DB_Functions();

$request = $db->getrequestByRequestId($_GET['requestId']);

$dir = "requestPics/";
$image = $dir.$request["requestId"].".jpg";
echo '<img src="'.$image.'" width="70%" height="60%" hspace="15%" style="margin-bottom:50px"/><br />';




  
  




echo '<label style="font-size: 40px;"> Name: </label>';
echo '<label style="font-size: 60px;"> '.$request["name"].' </label><br><br>';

echo '<label style="font-size: 40px;"> Reason: </label>';
echo '<label style="font-size: 40px;"> '.$request["reason"].' </label><br><br>';

echo '<label style="font-size: 40px;"> Arrival time: </label>';
echo '<label style="font-size: 40px;"> '.$request["time"].' </label><br>';


//echo $image;


//echo '<img src="data:image/jpeg;base64,' . base64_encode( $request['image'] ) . '" />';


echo '<form action="submitted.php"> <input type="hidden" name="requestId" value="';
echo $_GET['requestId'];
echo '"> <button type="submit" style="height:200px;width:70%; margin-top:100px;margin-left:15%; background-color: #4CAF50;font-size: 40px;color:white" name="action" value="accept">Accept</button> <br> <br> <button type="submit" style="height:200px;width:70%; margin-left:15%; margin-bottom:200px; background-color: #f44336;font-size: 40px;color:white" name="action" value="reject">Reject</button>
</form>';
?>
