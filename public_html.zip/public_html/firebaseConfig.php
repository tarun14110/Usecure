<?php


// Firebase API Key
define('FIREBASE_API_KEY', 'AIzaSyBVGd34bAZ9GHIfMiuGur3GfuG5uErzo30');


?>