<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if(isset($_POST['ImageName'])){
$imgname = $_POST['ImageName'];
$imsrc = base64_decode($_POST['base64']);
$fp = fopen("requestPics/".$imgname, 'w');
fwrite($fp, $imsrc);
echo "broda";
if(fclose($fp)){
 echo "Image uploaded";
}else{
 echo "Error uploading image";
}
}
?>