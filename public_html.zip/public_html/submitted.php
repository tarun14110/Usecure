<html>
<body>
Your response Successfully Submitted as 
<? 
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'DB_Functions.php';
$db = new DB_Functions();

$status = $_GET["action"];
$requestId = $_GET["requestId"];

$db->updateEntryStatus($requestId, $status);

echo $_GET["action"];
//echo $_GET["requestId"];



$users = $db->getAllSecurityUsersGCMId();



//print_r($users);

//echo $users[0];


//echo "polly";


for ($p = 0; $p < count($users); ++$p) {

$title = "UltraSecure";
$message = "User responded to the request.";
$push_type = "individual";


// Enabling error reporting
       // error_reporting(-1);
        //ini_set('display_errors', 'On');
//echo "holy";
        require_once 'firebase.php';
        require_once 'push.php';

        $firebase = new Firebase();
        $push = new Push();

        // optional payload
        $payload = array();
        $payload['type'] = "request-response";
        $payload['requestId'] = $requestId;
        $payload['status'] = $status;

        // notification title
        $title = isset($title) ? $title : '';
        
        // notification message
        $message = isset($message) ? $message : '';
        
        // push type - single user / topic
        $push_type = isset($push_type) ? $push_type : '';
        
        // whether to include to image or not
        $include_image = FALSE;
//echo "lol";

        $push->setTitle($title);
        $push->setMessage($message);
        if ($include_image) {
            $push->setImage('http://api.androidhive.info/images/minion.jpg');
        } else {
            $push->setImage('');
        }
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);


        $json = '';
        $response = '';
//echo "popo";
        if ($push_type == 'topic') {
            $json = $push->getPush();
            $response = $firebase->sendToTopic('global', $json);
        } else if ($push_type == 'individual') {
            $json = $push->getPush();
            $regId = $users[$p];
            //echo $regId;
//echo "dodo";

            $response = $firebase->send($regId, $json);
        
	}else{
		echo "Error";
	}

}




?>


</body>
</html>