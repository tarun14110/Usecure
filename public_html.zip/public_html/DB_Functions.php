<?php
 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
class iimysqli_result {
        public $stmt, $ncols;
}  

class DB_Functions {
 
    private $conn;
    

    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
 


    function iimysqli_get_result($stmt) {
      $metadata = $stmt->result_metadata();
      $ret = new iimysqli_result;
      if (!$ret || !$metadata) return NULL; //the latter because this gets called whether we are adding/updating as well as returning
      $ret->ncols = $metadata->field_count;
      $ret->stmt = $stmt;
      $metadata->free_result();
      return $ret;
   }

     function iimysqli_result_fetch_array(&$result) {
      $stmt = $result->stmt;
      $stmt->store_result();
      $resultkeys = array();
      $thisName = "";
      for ( $i = 0; $i < $stmt->num_rows; $i++ ) {
            $metadata = $stmt->result_metadata();
            while ( $field = $metadata->fetch_field() ) {
                $thisName = $field->name;
                $resultkeys[] = $thisName;
            }
      }

      $ret = array();
      $code = "return mysqli_stmt_bind_result(\$result->stmt ";
      for ($i=0; $i<$result->ncols; $i++) {
          $ret[$i] = NULL;
          $theValue = $resultkeys[$i];
          $code .= ", \$ret['$theValue']";
      }

      $code .= ");";
      if (!eval($code)) {
        return NULL;
      }

      // This should advance the "$stmt" cursor.
      if (!mysqli_stmt_fetch($result->stmt)) {
        return NULL;
      }

      // Return the array we built.
      return $ret;
    }
    
    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($contact, $name, $email, $password) {
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt
 
        $stmt = $this->conn->prepare("INSERT INTO users(contact, name, email, encrypted_password, salt) VALUES(?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $contact, $name, $email, $encrypted_password, $salt);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE contact = ?");
            $stmt->bind_param("s", $contact);
            $stmt->execute();
            $result = $this->iimysqli_get_result($stmt);
            $user = $this->iimysqli_result_fetch_array($result);
            $stmt->close();
 
            return $user;
        } else {
            return false;
        }
    }

    /**
     * Storing new security user
     * returns user details
     */
    public function storeUserOfSecurity($contact, $name, $email, $password) {
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt
 
        $stmt = $this->conn->prepare("INSERT INTO securityUsers(contact, name, email, encrypted_password, salt) VALUES(?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $contact, $name, $email, $encrypted_password, $salt);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM securityUsers WHERE contact = ?");
            $stmt->bind_param("s", $contact);
            $stmt->execute();
            $result = $this->iimysqli_get_result($stmt);
            $user = $this->iimysqli_result_fetch_array($result);
            $stmt->close();
 
            return $user;
        } else {
            return false;
        }
    }
 
    /**
     * Get user by email and password
     */
    public function getUserByEmailAndPassword($contact, $password) {
 
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE contact = ?");
 
        $stmt->bind_param("s", $contact);
 
        if ($stmt->execute()) {
            $result = $this->iimysqli_get_result($stmt);
            $user = $this->iimysqli_result_fetch_array($result);
            $stmt->close();
 
            // verifying user password
            //echo $user["contact"];
            $salt = $user["salt"];
            $encrypted_password = $user["encrypted_password"];
            $hash = $this->checkhashSSHA($salt, $password);
            // check for password equality
            if ($encrypted_password == $hash) {
                // user authentication details are correct
                return $user;
            }
        } else {
            return NULL;
        }
    }


    /**
     * Get user by contact
     */
    public function getUserGCMRegId($contact) {
 
        $stmt = $this->conn->prepare("SELECT regId FROM users WHERE contact = ?");
 
        $stmt->bind_param("s", $contact);
 
        if ($stmt->execute()) {
            $result = $this->iimysqli_get_result($stmt);
            $user = $this->iimysqli_result_fetch_array($result);
            $stmt->close();
 
            // verifying user password
            //echo $user["contact"];

            return $user["regId"];
            
        } else {
            return NULL;
        }
    }


  /**
     * Get user by contact and password for security person 
     */
    public function getUserByEmailAndPasswordOfSecurity($contact, $password) {
 
        $stmt = $this->conn->prepare("SELECT * FROM securityUsers WHERE contact = ?");
 
        $stmt->bind_param("s", $contact);
 
        if ($stmt->execute()) {
            $result = $this->iimysqli_get_result($stmt);
            $user = $this->iimysqli_result_fetch_array($result);
            $stmt->close();
 
            // verifying user password
            //echo $user["contact"];
            $salt = $user["salt"];
            $encrypted_password = $user["encrypted_password"];
            $hash = $this->checkhashSSHA($salt, $password);
            // check for password equality
            if ($encrypted_password == $hash) {
                // user authentication details are correct
                $user = substr($user , strpos($user , "{"));
                return $user;
            }
        } else {
            return NULL;
        }
    }



  /**
     * Get all Security users
     */
    public function getAllSecurityUsersGCMId() {
 
        $stmt = $this->conn->prepare("SELECT * FROM securityUsers");
 
        if ($stmt->execute()) {
            $result = $this->iimysqli_get_result($stmt);
$users= array();

$i = 0;
$user = $this->iimysqli_result_fetch_array($result);
while ($user != NULL){
            $users[$i] = $user["regId"];
$i = $i + 1;
$user = $this->iimysqli_result_fetch_array($result);
}
            $stmt->close();
            return $users;
        } else {
            return NULL;
        }
    }
 
    /**
     * Check user is existed or not
     */
    public function isUserExisted($contact) {
        $stmt = $this->conn->prepare("SELECT contact from users WHERE contact = ?");
 
        $stmt->bind_param("s", $contact);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    /**
     * Check user is existed or not
     */
    public function isUserExistedOfSecurity($contact) {
        $stmt = $this->conn->prepare("SELECT contact from securityUsers WHERE contact = ?");
 
        $stmt->bind_param("s", $contact);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }
 
    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password) {
 
        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }
 
    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($salt, $password) {
 
        $hash = base64_encode(sha1($password . $salt, true) . $salt);
 
        return $hash;
    }

     /**
     * Update regId (GCM notification unique Id) of the contact
     * returns user details
     */
    public function updateRegId($contact, $regId) {

        $stmt = $this->conn->prepare("UPDATE securityUsers SET regid = ? WHERE contact = ?");
        $stmt->bind_param("ss", $regId, $contact);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
 
    }

public function updateProfilePic($contact, $image) {
    $path = "uploads/$contact.png";
    $actualpath = "http://usecure.site88.net/$path";     
             /*   $stmt = $this->conn->prepare("UPDATE users SET photo = , imageName= ? WHERE contact = ?");
                $stmt->bind_param("sss", $actualpath, $contact, $contact);
                $result = $stmt->execute();*/
$sql = "UPDATE users SET photo = ? WHERE contact = ?";
$stmt = $mysqli->prepare($sql);
if($stmt){
    $stmt->bind_param("ss", $actualpath, $contact);
    $stmt->execute();
        
}else{
      echo 'failed to prepare() UPDATE \n';
       printf("Error: %s.\n", $stmt->error);

}
                 if(result){
      file_put_contents($path,base64_decode($image));
      echo "Successfully Uploaded";
    }
                $stmt->close();
}


public function updateNewRequest($contact, $requestId, $name, $reason, $time) {

 
        $stmt = $this->conn->prepare("INSERT INTO entryRequests(name, reason, requestId, contact, time) VALUES(?, ?, ?, ?, ?)");
echo "BRANDD".$visitorImage;        
$stmt->bind_param("sssss", $name, $reason, $requestId, $contact, $time);
        $result = $stmt->execute();
        $stmt->close();
 
     /*   // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM securityUsers WHERE contact = ?");
            $stmt->bind_param("s", $contact);
            $stmt->execute();
            $result = $this->iimysqli_get_result($stmt);
            $user = $this->iimysqli_result_fetch_array($result);
            $stmt->close();
 
            return $user;
        } else {
            return false;
        }*/
}

 
public function getAllUsers() {
$sql = "select * from users";
 
  $res = mysqli_query($this->conn,$sql);
if (!$res) {
    printf("Error: %s\n", mysqli_error($this->conn));
    exit();
}

$result = array();

          while($row = mysqli_fetch_array($res)){
    array_push($result,
    array('contact'=>$row[0],
    'name'=>$row[1],
    'email'=>$row[2],
    'address'=>$row[5],
    'profilePicUrl'=>$row[7]
  ));

}
  echo json_encode(array("result"=>$result));
 
  mysqli_close($this->conn);
 
}


 public function updateEntryStatus($requestId, $status) {

        $stmt = $this->conn->prepare("UPDATE entryRequests SET status = ? WHERE requestId = ?");
        $stmt->bind_param("ss", $status, $requestId);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
 
    }

 /**
     * Get request by requestId
     */
    public function getrequestByRequestId($requestId) {
        //echo $requestId."pa";
        $stmt = $this->conn->prepare("SELECT * FROM entryRequests WHERE requestId = ?");
        //echo $requestId;
        $stmt->bind_param("s", $requestId);
 
        if ($stmt->execute()) {
            $result = $this->iimysqli_get_result($stmt);
            $request = $this->iimysqli_result_fetch_array($result);
            $stmt->close();
           // echo $request["id"]."oo";
            return $request;
        } else {
            return NULL;
        }
    }

//adds new pre request
public function addNewPreRequest($name, $purpose, $contact, $visitingTime) {
  
 
        $stmt = $this->conn->prepare("INSERT INTO preRequests(name, reason, contact, visitingTime) VALUES(?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $purpose, $contact, $visitingTime);
        $result = $stmt->execute();
        $stmt->close();
 
}


}
 
?>