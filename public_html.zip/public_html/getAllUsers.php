<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'DB_Functions.php';
$db = new DB_Functions();

$db->getAllUsers();


?>