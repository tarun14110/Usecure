<?php
require_once 'DB_Functions.php';
$db = new DB_Functions();

	if($_SERVER['REQUEST_METHOD']=='POST'){
		
echo $_POST['image'];
echo $_POST['contact'];
		$image = $_POST['image'];
                $contact = $_POST['contact'];
if ($_POST['contact'] && $_POST['image']) {
 $db->updateProfilePic($contact, $image);
} else {
echo "Parameters required";
}
               


	}else{
		echo "Error";
	}
?>