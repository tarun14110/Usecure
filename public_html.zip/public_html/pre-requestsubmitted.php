<html>
<body>
Your pre-request Successfully Submitted.
<? 
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'DB_Functions.php';
$db = new DB_Functions();

$name = $_GET["name"];
$purpose = $_GET["purpose"];
$visitingtime = $_GET["visitingtime"];
$contact = $_GET["contact"];

echo $name.$purpose.$visitingtime;
$db->addNewPreRequest($name, $purpose, $contact, $visitingtime);

//echo $_GET["action"];
//echo $_GET["requestId"];





$users = $db->getAllSecurityUsersGCMId();



//print_r($users);

//echo $users[0];


//echo "polly";


for ($p = 0; $p < count($users); ++$p) {

$title = "UltraSecure";
$message = "New Pre-request";
$push_type = "individual";


// Enabling error reporting
       // error_reporting(-1);
        //ini_set('display_errors', 'On');
//echo "holy";
        require_once 'firebase.php';
        require_once 'push.php';

        $firebase = new Firebase();
        $push = new Push();

        // optional payload
        $payload = array();
        $payload['type'] = "pre-request";
        $payload['name'] = $name;
        $payload['reason'] = $purpose;
        $payload['visitingtime'] = $visitingtime;
        $payload['contact'] = $contact;

        // notification title
        $title = isset($title) ? $title : '';
        
        // notification message
        $message = isset($message) ? $message : '';
        
        // push type - single user / topic
        $push_type = isset($push_type) ? $push_type : '';
        
        // whether to include to image or not
        $include_image = FALSE;
//echo "lol";

        $push->setTitle($title);
        $push->setMessage($message);
        if ($include_image) {
            $push->setImage('http://api.androidhive.info/images/minion.jpg');
        } else {
            $push->setImage('');
        }
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);


        $json = '';
        $response = '';
//echo "popo";
        if ($push_type == 'topic') {
            $json = $push->getPush();
            $response = $firebase->sendToTopic('global', $json);
        } else if ($push_type == 'individual') {
            $json = $push->getPush();
            $regId = $users[$p];
            //echo $regId;
//echo "dodo";

            $response = $firebase->send($regId, $json);
        
	}else{
		echo "Error";
	}

}


?>