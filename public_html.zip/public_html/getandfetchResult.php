<?php
class IImysqli_result {
        public $stmt, $ncols;
}  

class DBObject {

    public function iimysqli_get_result($stmt) {
      $metadata = $stmt->result_metadata();
      $ret = new IImysqli_result;
      if (!$ret || !$metadata) return NULL; //the latter because this gets called whether we are adding/updating as well as returning
      $ret->ncols = $metadata->field_count;
      $ret->stmt = $stmt;
      $metadata->free_result();
      return $ret;
   }

   //this mimics mysqli_fetch_array by returning a new row each time until exhausted
    pubic function iimysqli_result_fetch_array(&$result) {
      $stmt = $result->stmt;
      $stmt->store_result();
      $resultkeys = array();
      $thisName = "";
      for ( $i = 0; $i < $stmt->num_rows; $i++ ) {
            $metadata = $stmt->result_metadata();
            while ( $field = $metadata->fetch_field() ) {
                $thisName = $field->name;
                $resultkeys[] = $thisName;
            }
      }

      $ret = array();
      $code = "return mysqli_stmt_bind_result(\$result->stmt ";
      for ($i=0; $i<$result->ncols; $i++) {
          $ret[$i] = NULL;
          $theValue = $resultkeys[$i];
          $code .= ", \$ret['$theValue']";
      }

      $code .= ");";
      if (!eval($code)) {
        return NULL;
      }

      // This should advance the "$stmt" cursor.
      if (!mysqli_stmt_fetch($result->stmt)) {
        return NULL;
      }

      // Return the array we built.
      return $ret;
    }
}

?>