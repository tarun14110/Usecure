<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

      require_once 'firebase.php';
        require_once 'push.php';
        $firebase = new Firebase();
        $push = new Push();
require_once 'DB_Functions.php';
$db = new DB_Functions();

	if($_SERVER['REQUEST_METHOD']=='POST'){
$db->updateNewRequest($_POST["contact"], $_POST["requestId"], $_POST["name"], $_POST["reason"], $_POST["time"]);

          $regId = $db->getUserGCMRegId($_POST["contact"]);

 // echo "<script>window.location = 'http://usecure.site88.net/index.php?regId='.$regId.'&message='.$_POST["name"].' came to meet you.'";

$url = "http://usecure.site88.net/index.php?regId=".$regId."&message=".$_POST["name"]." came to meet you&title=SmartSec&push_type=individual";

echo "TETSTETETETETTE".$url;
   // header("Location:".$url);

  //echo "<script>window.location = ".$url."</script>";









$title = "SmartSec";
$message = $_POST["name"]." came to meet you.";
$push_type = "individual";


// Enabling error reporting
        error_reporting(-1);
        ini_set('display_errors', 'On');

        require_once 'firebase.php';
        require_once 'push.php';

        $firebase = new Firebase();
        $push = new Push();

        // optional payload
        $payload = array();
        $payload['team'] = 'India';
        $payload['score'] = '5.6';

        // notification title
        $title = isset($title) ? $title : '';
        
        // notification message
        $message = isset($message) ? $message : '';
        
        // push type - single user / topic
        $push_type = isset($push_type) ? $push_type : '';
        
        // whether to include to image or not
        $include_image = isset($_POST['include_image']) ? TRUE : FALSE;


        $push->setTitle($title);
        $push->setMessage($message);
        if ($include_image) {
            $push->setImage('http://api.androidhive.info/images/minion.jpg');
        } else {
            $push->setImage('');
        }
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);


        $json = '';
        $response = '';

        if ($push_type == 'topic') {
            $json = $push->getPush();
            $response = $firebase->sendToTopic('global', $json);
        } else if ($push_type == 'individual') {
            $json = $push->getPush();
            $regId = isset($regId) ? $regId : '';
            $response = $firebase->send($regId, $json);
        }
	}else{
		echo "Error";
	}





?>