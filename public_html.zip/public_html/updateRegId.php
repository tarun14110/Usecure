<?php 
// error_reporting(E_ALL);
//ini_set('display_errors', 1);

require_once 'DB_Functions.php';
$db = new DB_Functions();

$contact   = urldecode($_POST['contact']);
$regId   = urldecode($_POST['regId']);

$result = $db->updateRegId($contact, $regId);

if ($result) {
echo "successfully updated";
} else {
echo "error while updating";
}
 
 ?>