<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'DB_Functions.php';
$db = new DB_Functions();

//$request = $db->getrequestByRequestId($_GET['requestId']);

echo '<form action = "pre-requestsubmitted.php">
<table width = "450px">
</tr>
<tr>
	<td>
	<label for = "name"> Visitor\'s name</label>
	</td>
	<td>
	<input type = "text" name = "name" maxlength = "50" size = "30">
	</td>
</tr>

<tr>
<td>
    <label for = "purpose">Purpose of visiting</label>
</td>
<td>
	<input type = "text" name = "purpose" maxlength = "50" size = "30">
</td>
</tr>

<tr>
<td>
    <label for = "phone_number">Registered phone number</label>
</td>
<td>
    <input type = "text" name = "contact" maxlength = "50" size = "30">
</td>
</tr>

<tr>
<td>
    <label for = "Visiting_time">Visitor\'s reaching time</label>
</td>
<td>
    <input type = "datetime-local" name = "visitingtime">
</td>
</tr>
</table>
<br> <font size = "3" color = "red">The person will be allowed to enter , if he came within 1 hour around the given time.<br>

</form>';


/*echo '<form action="pre-requestsubmitted.php">  Visiting person name: <input type="text" name="name"><br>';
echo 'Purpose: <input type="text" name="purpose" ><br>';
echo 'Your registered phone number: <input type="text" name="contact" ><br>';
echo 'Approx Visiting time (date and time): <input type="datetime-local" name="visitingtime"><br> The person will be allowed to enter , if he came within 1 hour around the given time.<br>';*/
echo '<input type="submit" value="Send"></form>';

?>
