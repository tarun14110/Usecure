<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

require_once 'DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);
if (isset($_POST['contact']) && isset($_POST['password'])) {
 
    // receiving the POST params
    $email = $_POST['contact'];
    $password = $_POST['password'];
 
    // get the user by email and password
    if (isset($_POST['isSecurity']) && $_POST['isSecurity'] == "true") {
       $user = $db->getUserByEmailAndPasswordOfSecurity($email, $password);
    } else { 
       $user = $db->getUserByEmailAndPassword($email, $password);
    }
    
 
    if ($user != false) {
        // use is found
        $response["error"] = FALSE;
        $response["user"]["name"] = $user["name"];
        $response["user"]["email"] = $user["email"];
        $response["user"]["contact"] = $user["contact"];
        $response["user"]["address"] = $user["Address"];
        echo json_encode($response);
    } else {
        // user is not found with the credentials
        $response["error"] = TRUE;
        $response["error_msg"] = "Login credentials are wrong. Please try again!";
        echo json_encode($response);
    }
} else {
    // required POST params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters contact or password is missing!";
    echo json_encode($response);
}
?>