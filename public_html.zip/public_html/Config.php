<?php
 
/**
 * Database config variables
 */
define("DB_HOST", "mysql1.000webhost.com");
define("DB_USER", "a4876302_uSecure");
define("DB_PASSWORD", "uSecure0");
define("DB_DATABASE", "a4876302_uSecure");
?>