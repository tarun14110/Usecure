<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);
 
if (isset($_GET['name']) && isset($_GET['contact']) && isset($_GET['password'])) {
 
    // receiving the GET params
    $name = $_GET['name'];
    $email = $_GET['email'];
    $contact = $_GET['contact'];
    $password = $_GET['password'];
 
    // check if user is already existed with the same email
    if ($db->isUserExistedOfSecurity($contact)) {
        // user already existed
        $response["error"] = TRUE;
        echo json_encode($response);
    } else {
        // create a new user
        $user = $db->storeUserOfSecurity($contact, $name, $email, $password);
        if ($user) {
            // user stored successfully
            $response["error"] = FALSE;
            $response["user"]["contact"] = $user["contact"];
            $response["user"]["name"] = $user["name"];
            $response["user"]["email"] = $user["email"];
            echo json_encode($response);
        } else {
            // user failed to store
            $response["error"] = TRUE;
            $response["error_msg"] = "Unknown error occurred in registration!";
            echo json_encode($response);
        }
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (name, contact or password) is missing!";
    echo json_encode($response);
}
?>